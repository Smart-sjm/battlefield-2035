(()=>{
  const root=document.documentElement;
  const ambient=document.querySelector('#ambientCanvas');
  const ambientContext=ambient?.getContext('2d');
  let width=innerWidth,height=innerHeight,dpr=Math.min(devicePixelRatio||1,1.7),mouseX=width/2,mouseY=height/2;
  const particles=Array.from({length:72},(_,index)=>({x:Math.random()*width,y:Math.random()*height,vx:(Math.random()-.5)*.18,vy:(Math.random()-.5)*.18,size:index%11===0?1.8:.7+Math.random()*.7,alpha:.13+Math.random()*.35}));
  function resizeAmbient(){if(!ambient)return;width=innerWidth;height=innerHeight;dpr=Math.min(devicePixelRatio||1,1.7);ambient.width=width*dpr;ambient.height=height*dpr;ambient.style.width=`${width}px`;ambient.style.height=`${height}px`;ambientContext.setTransform(dpr,0,0,dpr,0,0)}
  function renderAmbient(time){
    if(!ambientContext)return;ambientContext.clearRect(0,0,width,height);
    const gradient=ambientContext.createRadialGradient(mouseX,mouseY,0,mouseX,mouseY,430);gradient.addColorStop(0,'rgba(49,190,210,.055)');gradient.addColorStop(1,'rgba(49,190,210,0)');ambientContext.fillStyle=gradient;ambientContext.fillRect(0,0,width,height);
    ambientContext.strokeStyle='rgba(77,190,207,.035)';ambientContext.lineWidth=1;const drift=(time*.008)%80;for(let x=-80+drift;x<width+80;x+=80){ambientContext.beginPath();ambientContext.moveTo(x,0);ambientContext.lineTo(x-160,height);ambientContext.stroke()}
    for(let i=0;i<particles.length;i++){
      const particle=particles[i];const dx=mouseX-particle.x,dy=mouseY-particle.y,dist=Math.hypot(dx,dy)||1;if(dist<230){particle.vx-=dx/dist*.0018;particle.vy-=dy/dist*.0018}particle.vx*=.998;particle.vy*=.998;particle.x+=particle.vx;particle.y+=particle.vy;
      if(particle.x<-20)particle.x=width+20;if(particle.x>width+20)particle.x=-20;if(particle.y<-20)particle.y=height+20;if(particle.y>height+20)particle.y=-20;
      ambientContext.fillStyle=`rgba(105,226,236,${particle.alpha})`;ambientContext.beginPath();ambientContext.arc(particle.x,particle.y,particle.size,0,Math.PI*2);ambientContext.fill();
      for(let j=i+1;j<particles.length;j++){const other=particles[j];const link=Math.hypot(other.x-particle.x,other.y-particle.y);if(link<105){ambientContext.strokeStyle=`rgba(80,183,199,${.055*(1-link/105)})`;ambientContext.beginPath();ambientContext.moveTo(particle.x,particle.y);ambientContext.lineTo(other.x,other.y);ambientContext.stroke()}}
    }
    requestAnimationFrame(renderAmbient);
  }
  addEventListener('resize',resizeAmbient);addEventListener('pointermove',event=>{mouseX=event.clientX;mouseY=event.clientY;root.style.setProperty('--pointer-x',`${mouseX}px`);root.style.setProperty('--pointer-y',`${mouseY}px`)});resizeAmbient();requestAnimationFrame(renderAmbient);

  const mapPanel=document.querySelector('.map-panel');const mapCursor=document.querySelector('#mapCursor');
  if(mapPanel){
    mapPanel.addEventListener('pointermove',event=>{const rect=mapPanel.getBoundingClientRect();const x=event.clientX-rect.left,y=event.clientY-rect.top;mapPanel.style.setProperty('--map-glow-x',`${x}px`);mapPanel.style.setProperty('--map-glow-y',`${y}px`);root.style.setProperty('--map-parallax-x',`${(x/rect.width-.5)*-7}px`);root.style.setProperty('--map-parallax-y',`${(y/rect.height-.5)*-7}px`);if(mapCursor){mapCursor.style.left=`${x}px`;mapCursor.style.top=`${y}px`;const label=mapCursor.querySelector('span');if(label)label.textContent=`X ${String(Math.round(x/rect.width*900)).padStart(3,'0')} / Y ${String(Math.round(y/rect.height*560)).padStart(3,'0')}`}});
    mapPanel.addEventListener('pointerleave',()=>{root.style.setProperty('--map-parallax-x','0px');root.style.setProperty('--map-parallax-y','0px')});
  }

  const swarm=document.querySelector('#swarmCanvas');const swarmContext=swarm?.getContext('2d');let swarmWidth=0,swarmHeight=0,swarmDpr=1,swarmWasActive=false,launchAt=0;
  const swarmNodes=Array.from({length:24},(_,index)=>({ring:index<8?0:index<16?1:2,slot:index%8,phase:index*.71,speed:.72+(index%5)*.055,role:index%4}));
  function resizeSwarm(){if(!swarm||!mapPanel)return;const rect=mapPanel.getBoundingClientRect();swarmWidth=rect.width;swarmHeight=Math.max(200,rect.height-44);swarmDpr=Math.min(devicePixelRatio||1,1.6);swarm.width=swarmWidth*swarmDpr;swarm.height=swarmHeight*swarmDpr;swarm.style.width=`${swarmWidth}px`;swarm.style.height=`${swarmHeight}px`;swarmContext.setTransform(swarmDpr,0,0,swarmDpr,0,0)}
  function dronePosition(node,time,launchProgress){
    const centerX=swarmWidth*.57,centerY=swarmHeight*.53;const ringRadius=[74,136,202][node.ring];const angle=node.slot/8*Math.PI*2+time*.00016*node.speed+(node.ring%2?-.38:.18);const formationX=centerX+Math.cos(angle)*ringRadius*1.36;const formationY=centerY+Math.sin(angle)*ringRadius*.65+Math.sin(time*.0012+node.phase)*7;const startX=swarmWidth*.16+(node.slot%4)*7,startY=swarmHeight*.7+(node.ring*15);const eased=1-Math.pow(1-launchProgress,3);return{x:startX+(formationX-startX)*eased,y:startY+(formationY-startY)*eased,angle:angle+Math.PI/2}}
  function drawDrone(context,x,y,angle,index){context.save();context.translate(x,y);context.rotate(angle);const pulse=.88+Math.sin(performance.now()*.004+index)*.1;context.scale(pulse,pulse);context.strokeStyle=index%4===0?'rgba(112,246,207,.92)':'rgba(111,235,244,.9)';context.fillStyle='rgba(3,20,28,.93)';context.lineWidth=1.2;context.beginPath();context.moveTo(-7,-5);context.lineTo(7,5);context.moveTo(7,-5);context.lineTo(-7,5);context.stroke();for(const [rx,ry] of [[-8,-6],[8,-6],[-8,6],[8,6]]){context.beginPath();context.arc(rx,ry,3.6,0,Math.PI*2);context.fill();context.stroke()}context.fillRect(-4.5,-5.5,9,11);context.strokeRect(-4.5,-5.5,9,11);context.restore()}
  function renderSwarm(time){
    if(!swarmContext||!mapPanel){requestAnimationFrame(renderSwarm);return}const active=mapPanel.classList.contains('uav-active');if(active&&!swarmWasActive)launchAt=time;swarmWasActive=active;swarmContext.clearRect(0,0,swarmWidth,swarmHeight);if(active){const launchProgress=Math.min(1,(time-launchAt)/1900);const positions=swarmNodes.map(node=>dronePosition(node,time,launchProgress));
      for(let i=0;i<positions.length;i++)for(let j=i+1;j<positions.length;j++){const a=positions[i],b=positions[j],distance=Math.hypot(a.x-b.x,a.y-b.y);if(distance<116){swarmContext.strokeStyle=`rgba(80,222,232,${.22*(1-distance/116)})`;swarmContext.lineWidth=.8;swarmContext.beginPath();swarmContext.moveTo(a.x,a.y);swarmContext.lineTo(b.x,b.y);swarmContext.stroke()}}
      positions.forEach((position,index)=>drawDrone(swarmContext,position.x,position.y,position.angle,index));
    }requestAnimationFrame(renderSwarm)
  }
  if(swarm&&mapPanel){new ResizeObserver(resizeSwarm).observe(mapPanel);resizeSwarm();requestAnimationFrame(renderSwarm)}

  window.playSceneCinematic=(scene)=>{const overlay=document.querySelector('#sceneCinematic');if(!overlay)return;document.querySelector('#cinematicNumber').textContent=scene.number;document.querySelector('#cinematicTitle').textContent=scene.title;overlay.classList.remove('is-hidden');clearTimeout(overlay._timer);overlay._timer=setTimeout(()=>overlay.classList.add('is-hidden'),1180)};
})();
