(function(){
  const KEY='blackout2035:state';
  const DATA=window.BLACKOUT_DATA;
  const channel='BroadcastChannel' in window?new BroadcastChannel('blackout2035'):null;
  const defaults=()=>({scene:0,connected:18,demoMode:false,alertPulse:0,deployed:{},uav:{mode:'ready',active:0,sorties:0},poll:{id:null,open:false,votes:{A:0,B:0},voters:{}},updatedAt:Date.now()});
  let remote=false;
  let cache=defaults();
  try{cache={...cache,...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch(e){}
  const notify=()=>window.dispatchEvent(new CustomEvent('blackout-state',{detail:cache}));
  async function api(path,body){const r=await fetch(path,{method:body?'POST':'GET',headers:{'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined,cache:'no-store'});if(!r.ok)throw new Error('api');return r.json()}
  async function refresh(){
    try{const incoming=await api('/api/state');const changed=!remote||incoming.updatedAt!==cache.updatedAt;cache=incoming;remote=true;if(changed)notify();return cache}catch(e){const wasRemote=remote;remote=false;let incoming=cache;try{incoming={...defaults(),...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch(_){}const changed=wasRemote||incoming.updatedAt!==cache.updatedAt;cache=incoming;if(changed)notify();return cache}
  }
  async function action(type,payload={}){
    if(remote){try{cache=await api('/api/action',{type,...payload});notify();return cache}catch(e){remote=false}}
    const next={...cache,updatedAt:Date.now()};
    if(type==='setScene')next.scene=Math.max(0,Math.min(DATA.scenes.length-1,Number(payload.scene)));
    if(type==='next')next.scene=Math.min(DATA.scenes.length-1,next.scene+1);
    if(type==='prev')next.scene=Math.max(0,next.scene-1);
    if(type==='toggleDemo')next.demoMode=!next.demoMode;
    if(type==='alert')next.alertPulse=(next.alertPulse||0)+1;
    if(type==='deploy'){next.deployed={...next.deployed,[payload.tech]:true}}
    if(type==='launchUav')next.uav={mode:'airborne',active:24,sorties:(next.uav?.sorties||0)+1};
    if(type==='recallUav')next.uav={...(next.uav||{}),mode:'ready',active:0};
    if(type==='openPoll')next.poll={id:payload.pollId,open:true,votes:{A:0,B:0},voters:{}};
    if(type==='closePoll')next.poll={...next.poll,open:false};
    if(type==='demoResult')next.poll={id:payload.pollId||next.poll.id,open:false,votes:payload.votes||{A:18,B:42},voters:{}};
    if(type==='reset'){const keep=next.connected;Object.assign(next,defaults(),{connected:keep,scene:Number(payload.scene||0)})}
    cache=next;localStorage.setItem(KEY,JSON.stringify(cache));if(channel)channel.postMessage(cache);notify();return cache;
  }
  async function join(observerId){
    if(remote){try{cache=await api('/api/join',{observerId});notify();return cache}catch(e){remote=false}}
    const joinedKey='blackout2035:joined';if(!localStorage.getItem(joinedKey)){localStorage.setItem(joinedKey,'1');cache.connected=(cache.connected||0)+1;localStorage.setItem(KEY,JSON.stringify(cache))}notify();return cache;
  }
  async function vote(observerId,pollId,option){
    if(remote){try{cache=await api('/api/vote',{observerId,pollId,option});notify();return cache}catch(e){remote=false}}
    if(cache.poll.open&&cache.poll.id===pollId&&!cache.poll.voters?.[observerId]){cache.poll.votes[option]=(cache.poll.votes[option]||0)+1;cache.poll.voters={...(cache.poll.voters||{}),[observerId]:option};localStorage.setItem(KEY,JSON.stringify(cache));if(channel)channel.postMessage(cache);notify()}return cache;
  }
  async function info(){try{return await api('/api/info')}catch(e){return{observerUrl:location.href.replace(/[^/]*$/,'observer.html'),remote:false}}}
  if(channel)channel.onmessage=e=>{cache=e.data;notify()};
  window.addEventListener('storage',e=>{if(e.key===KEY&&e.newValue){try{cache=JSON.parse(e.newValue);notify()}catch(_){}}});
  setInterval(refresh,1000);
  window.BlackoutSync={refresh,action,join,vote,info,get state(){return cache},get remote(){return remote}};
})();
