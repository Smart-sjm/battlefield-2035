const $=selector=>document.querySelector(selector);
const $$=selector=>document.querySelectorAll(selector);

const STATUS_ZH={LOCKED:'未解锁',CHECKING:'自检中',ONLINE:'在线',STANDBY:'待命',AVAILABLE:'可部署',DEGRADED:'性能下降',DEPLOYING:'部署中',OVERLOAD:'数据过载',CHARGING:'充能中'};
const RISK_ZH={STANDBY:'待命',ELEVATED:'较高',UNKNOWN:'未知',HIGH:'高',CRITICAL:'严重',CONTROLLED:'受控',SATURATED:'饱和',DECISION:'待决策',SECURE:'安全'};
const CODE_ZH={BOOT:'系统启动','MISSION BRIEF':'任务简报','BLIND ZONE':'信息盲区','GNSS LOST':'定位失效','LOAD LIMIT':'负载极限','HIGH RISK':'高危区域',SWARM:'蜂群展开','DATA OVERLOAD':'信息过载','AI DECISION':'人机决策','LOW ALTITUDE THREAT':'低空威胁','MISSION COMPLETE':'任务完成'};
const ALERT_ZH={
  'TACTICAL CORE INITIALIZED':'战术核心初始化完成','MISSION PACKAGE RECEIVED':'任务数据包已接收','VISUAL INFORMATION INSUFFICIENT':'区域视觉信息不足','GNSS INTERFERENCE DETECTED':'检测到卫星导航干扰','HUMAN PERFORMANCE LIMIT':'人员机动能力接近阈值','DECISION REQUIRED':'需要指挥决策','SWARM MODE AUTHORIZED':'无人蜂群模式已授权','INFORMATION OVERLOAD':'任务信息流过载','AI RECOMMENDATION: ROUTE BRAVO / 67%':'智能中枢建议：BRAVO路线 / 置信度67%','LOW ALTITUDE OBJECTS INBOUND':'检测到低空目标接近','ALL PRIMARY OBJECTIVES COMPLETE':'全部主要任务目标已完成'
};
const EVENT_ZH={
  'AUTHORIZATION KEY ACCEPTED':'任务授权密钥已确认','LOCAL ARCHIVE MOUNTED':'本地任务档案已挂载','OBSERVER NETWORK READY':'联合观察员网络已就绪','WAITING FOR OPERATION ENTRY':'等待进入推演','TEAM-A ENTERED SECTOR 07':'ALPHA小组进入第七任务区','PRIMARY ROUTE CALCULATED':'主行进路线计算完成','TARGET ZONE PARTIALLY OBSCURED':'目标区域部分信息不可见','MISSION CONTROL ACTIVE':'任务指挥链路已激活','OPTICAL FEED DEGRADED':'光学回传质量下降','THERMAL LAYER UNAVAILABLE':'热成像信息层不可用','TACTICAL TAGS NOT RESOLVED':'战术目标标签无法解析','AR FUSION PACKAGE REQUESTED':'已请求增强现实融合模块','SATELLITE LOCK LOST':'卫星定位锁定丢失','POSITION ERROR EXCEEDS THRESHOLD':'定位误差超过任务阈值','TEAM-A MARKER DRIFTING':'ALPHA小组位置标记漂移','ALTERNATIVE NAVIGATION REQUESTED':'已请求替代导航方案','TEAM LOAD ABOVE NOMINAL':'任务单元负载高于额定值','FATIGUE INDEX RISING':'人员疲劳指数持续上升','OBSTACLE FIELD DETECTED':'前方检测到复杂障碍区','EXO ASSIST PACKAGE AVAILABLE':'外骨骼辅助模块可用','TOXIC SIGNATURE DETECTED':'检测到异常环境特征','STRUCTURAL STABILITY UNKNOWN':'区域结构稳定性未知','HUMAN ENTRY RISK: HIGH':'人员进入风险：高','COMMAND DECISION REQUESTED':'已向指挥中心请求决策','UAV-01 COVERAGE INSUFFICIENT':'单机侦察覆盖不足','DISTRIBUTED TASKING ONLINE':'分布式任务分配上线','16 AUTONOMOUS NODES DEPLOYED':'16个自主节点已部署','AREA COVERAGE EXPANDING':'区域侦察覆盖持续扩大','18 VIDEO CHANNELS ACTIVE':'18路视频回传已接入','SENSOR QUEUE SATURATED':'传感数据队列已饱和','OPERATOR LOAD ABOVE LIMIT':'操作员信息负荷超限','AI FUSION REQUESTED':'已请求智能数据融合','MULTI-SOURCE FUSION COMPLETE':'多源信息融合完成','2 ROUTES REMAIN':'筛选出2条候选路线','ROUTE BRAVO CONFIDENCE: 67%':'BRAVO路线置信度：67%','HUMAN CONFIRMATION REQUIRED':'等待人工确认','MULTIPLE TRACKS DETECTED':'检测到多个低空航迹','EXFIL ROUTE UNDER THREAT':'安全撤离通道受到威胁','TRACKING SOLUTION ACQUIRED':'目标跟踪解算完成','DIRECTED ENERGY PACKAGE READY':'定向能防御模块就绪','TARGET RECOVERED':'失联目标已定位','EXFIL ROUTE SECURED':'安全撤离通道已恢复','TEAM-A RETURNED':'ALPHA小组完成返回','RETROSPECTIVE SEQUENCE READY':'技术回溯序列已就绪'
};
const SYSTEM_NAMES={AR:'增强现实',NAV:'多源导航',EXO:'外骨骼',UAV:'无人蜂群',AI:'智能融合',DEW:'定向能'};
const TECH_ACTIONS={ar:'部署 AR 信息层',nav:'执行多源重定位',exo:'启用外骨骼辅助',uav:'展开无人蜂群',ai:'启动智能融合',dew:'部署定向能模块'};
const TECH_LABELS={ar:'增强现实与数字化士兵',nav:'无卫星导航定位',exo:'外骨骼与人机协同',uav:'无人蜂群协同',ai:'AI融合与可信决策',dew:'定向能防御'};
const VIDEO_PATHS={ar:'assets/videos/ar-fiction.mp4',nav:'assets/videos/nav-fiction.mp4',exo:'assets/videos/exo-fiction.mp4',uav:'assets/videos/uav-fiction.mp4',ai:'assets/videos/ai-fiction.mp4',dew:'assets/videos/dew-fiction.mp4'};
const VIDEO_DESCRIPTIONS={ar:'战术视野与信息叠加',nav:'导航失效与位置漂移',exo:'动力装甲与负重增强',uav:'多机协同与区域覆盖',ai:'智能中枢与决策建议',dew:'光束防御与低空拦截'};
const CHECKS=[['战术核心','TACTICAL CORE','在线'],['传感网络','SENSOR NETWORK','在线'],['导航链路','GNSS LINK','安全'],['智能中枢','AI CORE','待命'],['本地档案','ARCHIVE','就绪'],['观察员网络','OBSERVER','可接入']];
const TAB_NAMES={fiction:'科幻想象',reality:'现实技术',principle:'核心原理',limitation:'工程边界'};
const ENTITY_DETAILS={bridge:['交通节点','峡谷桥','连接北侧设施与南部撤离路线，目前结构完整。'],compound:['任务设施','工业设施区','包含三座主要建筑，热源与弱通信信号仍在持续。'],tower:['通信设施','高地通信塔','可作为无人机中继节点，当前链路质量82%。'],lz:['空中节点','LZ-2 起降区','无人机群待命区，可展开12个轻型侦察节点。'],objective:['搜寻目标','待搜寻目标','区域内检测到微弱生命特征，需要持续缩小定位范围。'],uav01:['无人平台','UAV-01 / 领航节点','负责路径规划与编组通信中继。'],uav02:['无人平台','UAV-02 / 光学节点','搭载可见光侦察载荷，执行区域建图。'],uav03:['无人平台','UAV-03 / 热成像节点','负责低照度与热特征搜索。'],uav04:['无人平台','UAV-04 / 中继节点','扩展蜂群通信范围并监控链路质量。']};

let state=BlackoutSync.state;
let activeTech=null;
let techTab='fiction';
let lastAlert=-1;
let modalOpen=false;
let audioOn=true;
let missionEntered=false;
const videoReady={};
let mediaInventoryPromise=null;
let mapLayer='terrain';
let mapZoom=0;
let lastSceneVisit=-1;
let autoVideoTimer=null;

$('#bootChecks').innerHTML=CHECKS.map(([zh,en,status])=>`<div class="boot-check"><span>${zh}<small>${en}</small></span><b>${status}</b></div>`).join('');
$('#timelineList').innerHTML=BLACKOUT_DATA.timeline.map(([year,name,detail],index)=>`<div style="--i:${index}"><b>${year}</b><span><strong>${name}</strong><small>${detail}</small></span></div>`).join('');

function translateAlert(value){return ALERT_ZH[value]||value}
function translateEvent(value){return EVENT_ZH[value]||value}
function scenePhase(scene){return CODE_ZH[scene.code]||scene.title}
function modal(selector){modalOpen=true;$(selector).classList.remove('is-hidden')}
function closeModals(){$$('.modal-layer').forEach(layer=>layer.classList.add('is-hidden'));modalOpen=false}
function toast(message){const node=$('#toast');node.textContent=message;node.classList.add('show');clearTimeout(node._timer);node._timer=setTimeout(()=>node.classList.remove('show'),2200)}
function beep(freq=620,duration=.09,type='sine'){
  if(!audioOn)return;
  try{const context=new (window.AudioContext||window.webkitAudioContext)();const oscillator=context.createOscillator();const gain=context.createGain();oscillator.type=type;oscillator.frequency.value=freq;gain.gain.setValueAtTime(.04,context.currentTime);gain.gain.exponentialRampToValueAtTime(.001,context.currentTime+duration);oscillator.connect(gain).connect(context.destination);oscillator.start();oscillator.stop(context.currentTime+duration)}catch(_error){}
}

function showDashboard(){
  const boot=$('#boot');boot.classList.add('boot-exit');
  setTimeout(()=>{boot.classList.add('is-hidden');$('#dashboard').classList.remove('is-hidden')},360);
}
function enterOperation(){
  missionEntered=true;showDashboard();modal('#briefingModal');beep(520,.13);
}
function startMission(){
  closeModals();
  if(state.scene===0)BlackoutSync.action('setScene',{scene:1});
  toast('任务 BX-07A 已启动');beep(760,.16);
}

function systemStatus(name,scene){return state.deployed?.[name.toLowerCase()]?'ONLINE':scene.status[name]}
function renderSystems(scene){
  $('#systemList').innerHTML=BLACKOUT_DATA.systems.map(name=>{
    const raw=systemStatus(name,scene);const locked=raw==='LOCKED';const warning=['DEGRADED','OVERLOAD','CHARGING'].includes(raw);const progress=locked?0:raw==='AVAILABLE'?58:raw==='STANDBY'?34:raw==='DEPLOYING'?76:warning?48:100;
    return `<button class="system-row ${locked?'locked':''} ${warning?'warning':''}" data-system="${name}" ${locked?'aria-disabled="true"':''}><span>${name}<small>${SYSTEM_NAMES[name]}</small></span><i><em style="width:${progress}%"></em></i><div class="system-state"><b>${STATUS_ZH[raw]||raw}</b><small>${raw}</small></div></button>`;
  }).join('');
  $$('[data-system]').forEach(button=>button.onclick=()=>{
    const key=Object.keys(BLACKOUT_DATA.techs).find(id=>BLACKOUT_DATA.techs[id].short===button.dataset.system);
    if(key)openTech(key);
  });
}
function renderEvents(scene){
  const base=32+state.scene*4;
  $('#eventLog').innerHTML=scene.events.map((raw,index)=>{
    const message=translateEvent(raw);const second=11+index*7;const warning=/丢失|超过|风险|过载|威胁|下降|超限|饱和|异常|不可用|未知/.test(message);
    return `<div class="event-row"><time>19:${String(base%60).padStart(2,'0')}:${String(second).padStart(2,'0')}</time><b class="${warning?'warning':'info'}">${warning?'警告':'系统'}</b><span>${message}</span></div>`;
  }).join('');
}
function renderMap(scene){
  const mode=scene.map;
  ['blindField','driftGhosts','uavLayer','threatLayer','aiLayer'].forEach(id=>$('#'+id).classList.remove('visible'));
  if(['blind','risk'].includes(mode))$('#blindField').classList.add('visible');
  if(mode==='drift')$('#driftGhosts').classList.add('visible');
  if(['swarm','overload','ai','threat','complete'].includes(mode))$('#uavLayer').classList.add('visible');
  if(mode==='threat')$('#threatLayer').classList.add('visible');
  if(mode==='ai')$('#aiLayer').classList.add('visible');
  $('#teamMarker').classList.toggle('drifting',mode==='drift');
  const uavActive=state.uav?.mode==='airborne'||['swarm','overload','ai','threat','complete'].includes(mode);
  $('.map-panel').className=`map-panel panel mode-${mode} layer-${mapLayer} zoom-${mapZoom} ${uavActive?'uav-active':''}`;
  $('#airNodes').textContent=`${uavActive?(state.uav?.active||24):0} / 24`;
}

function handleSceneArrival(scene){
  if(state.scene===lastSceneVisit)return;
  const arrivedScene=state.scene;lastSceneVisit=arrivedScene;clearTimeout(autoVideoTimer);
  if(arrivedScene===0)return;
  if(window.playSceneCinematic)window.playSceneCinematic(scene);
  if(!scene.tech)return;
  const attemptOpen=(remaining=6)=>{if(state.scene!==arrivedScene)return;if(modalOpen&&remaining>0){autoVideoTimer=setTimeout(()=>attemptOpen(remaining-1),700);return}if(!modalOpen)openVideoPreview(scene.tech,{automatic:true,scene})};
  autoVideoTimer=setTimeout(()=>attemptOpen(),1450);
}
function renderPoll(){
  const scene=BLACKOUT_DATA.scenes[state.scene];const pollId=scene.poll||state.poll?.id;const poll=pollId&&BLACKOUT_DATA.polls[pollId];
  if(!poll)return;
  $('#pollTitle').textContent=poll.title;$('#pollQuestion').textContent=poll.question;
  $('#pollOptions').innerHTML=poll.options.map(option=>`<div><b>${option.id}</b><span>${option.label}</span></div>`).join('');
  const votes=state.poll?.id===pollId?state.poll.votes:{A:0,B:0};const total=(votes?.A||0)+(votes?.B||0);
  $('#resultBars').innerHTML=poll.options.map(option=>{const count=votes?.[option.id]||0;const percent=total?Math.round(count/total*100):0;return `<div><span>${option.id}</span><i><em style="width:${percent}%"></em></i><b>${percent}%</b></div>`}).join('');
  $('#responseCount').textContent=`${total} 份有效反馈`;$('#openPollBtn').textContent=state.poll?.open?'投票通道已开启':'向观察员发起投票';
}
function renderRoute(sceneIndex){
  const routes=[['01','进入任务区',1],['02','恢复战场感知',2],['03','搜寻与决策',6],['04','建立撤离通道',9]];
  $('#routeList').innerHTML=routes.map(([number,label,start],index)=>{const next=routes[index+1]?.[2]??99;const active=sceneIndex>=start&&sceneIndex<next;const done=sceneIndex>=next;return `<span class="${active?'active':''} ${done?'done':''}">${number} / ${label}</span>`}).join('');
}
function renderSceneNavigation(){
  $('#sceneNavList').innerHTML=BLACKOUT_DATA.scenes.map((scene,index)=>`<button class="scene-nav-item ${index===state.scene?'active':''} ${index<state.scene?'done':''}" data-jump="${index}"><b>${scene.number}</b><span>${scene.title}</span><small>${scene.code}</small></button>`).join('');
  $$('[data-jump]').forEach(button=>button.onclick=()=>{BlackoutSync.action('setScene',{scene:Number(button.dataset.jump)});closeModals()});
}
function render(next){
  state=next||BlackoutSync.state;const scene=BLACKOUT_DATA.scenes[state.scene]||BLACKOUT_DATA.scenes[0];const alertText=translateAlert(scene.alert);
  $('#bootConnected').textContent=`${state.connected||0} / 60`;
  $('#sceneLabel').textContent=`场景 / ${scene.number}`;$('#sceneTitle').textContent=scene.title;$('#sceneObjective').textContent=scene.objective;
  $('#phaseLabel').textContent=scenePhase(scene);$('#riskLabel').textContent=RISK_ZH[scene.risk]||scene.risk;$('#riskLabel').className=`risk risk-${scene.risk.toLowerCase()}`;
  $('#progressText').textContent=`${scene.progress}%`;$('#progressBar').style.width=`${scene.progress}%`;$('#sceneTime').textContent=scene.time;
  $('#sceneIndex').textContent=`${scene.number} / 10`;$('#sceneProgress').style.background=`linear-gradient(90deg,var(--cyan) ${scene.progress}%,#17323d ${scene.progress}%)`;
  $('#actionHint').textContent=`${scene.title} // ${alertText}`;$('#mapAlert strong').textContent=alertText;
  $('#dataRate').textContent=scene.rate;$('#telemetryRate').textContent=scene.rate;$('#coverage').textContent=`${scene.coverage}%`;$('#positionError').textContent=scene.error;
  $('#networkState').textContent=state.demoMode?'演示模式':'安全连接';$('#operationState').textContent=state.demoMode?'离线续航模式':'任务运行中';
  renderSystems(scene);renderEvents(scene);renderMap(scene);renderPoll();renderRoute(state.scene);renderSceneNavigation();
  $('#techBtn').disabled=!scene.tech;$('#deployBtn').disabled=!scene.tech;$('#pollBtn').disabled=!scene.poll;$('#prevBtn').disabled=state.scene<=0;$('#nextBtn').disabled=state.scene>=BLACKOUT_DATA.scenes.length-1;
  const pollText=$('#pollBtn').childNodes[0];if(pollText&&pollText.nodeType===3)pollText.nodeValue=state.poll?.open?'关闭投票 ':'决策投票 ';
  document.body.classList.toggle('critical',['CRITICAL','HIGH'].includes(scene.risk));
  if(state.alertPulse!==lastAlert){if(lastAlert>=0){$('#alertFlash').classList.remove('pulse');requestAnimationFrame(()=>$('#alertFlash').classList.add('pulse'));beep(220,.22,'sawtooth');toast(alertText)}lastAlert=state.alertPulse}
  if(state.scene===10&&!$('#timelineModal').dataset.shown){$('#timelineModal').dataset.shown='1';setTimeout(()=>modal('#timelineModal'),550)}
  if(state.scene!==10)delete $('#timelineModal').dataset.shown;
  if(!$('#uavModal').classList.contains('is-hidden'))renderUavConsole();if(!$('#intelModal').classList.contains('is-hidden'))renderIntel();
  handleSceneArrival(scene);
}

async function probeVideo(id){
  if(id in videoReady)return videoReady[id];
  try{mediaInventoryPromise=mediaInventoryPromise||fetch('/api/media',{cache:'no-store'}).then(response=>response.ok?response.json():{});const inventory=await mediaInventoryPromise;Object.assign(videoReady,inventory);videoReady[id]=Boolean(inventory[id])}catch(_error){videoReady[id]=false}
  return videoReady[id];
}
function videoPlaceholder(id){
  const filename=VIDEO_PATHS[id].split('/').pop();
  return `<div class="video-stage" data-video-preview="${id}" role="button" tabindex="0" title="打开影片预览窗口"><div class="video-placeholder"><span class="play-mark"></span><div class="video-placeholder-copy"><div><span>点击打开影片窗口</span><b>${VIDEO_DESCRIPTIONS[id]}</b></div><small>${filename}<br>建议 5–8 秒</small></div></div></div>`;
}
async function renderTech(){
  const id=activeTech;const tech=BLACKOUT_DATA.techs[id];if(!tech)return;
  const index=['fiction','reality','principle','limitation'].indexOf(techTab);let html='';
  if(techTab==='fiction'){
    const ready=await probeVideo(id);
    const media=ready?`<div class="video-stage" data-video-preview="${id}" role="button" tabindex="0"><video src="${VIDEO_PATHS[id]}" autoplay muted loop playsinline controls></video><span class="video-ready-badge">素材已接入</span></div>`:videoPlaceholder(id);
    html=`<div class="archive-frame">${media}<small>影视想象只是问题入口，后续页面将回到现实原理与工程边界。</small></div><div class="tech-copy"><span>科幻想象 / CONCEPT REFERENCE</span><h3>${tech.question}</h3><p>${tech.fiction}</p></div>`;
  }
  if(techTab==='reality')html=`<div class="reality-mark">现实</div><div class="tech-copy"><span>现实技术 / REAL-WORLD TECHNOLOGY</span><h3>${TECH_LABELS[id]}</h3><p>${tech.reality}</p></div>`;
  if(techTab==='principle')html=`<div class="principle-grid">${tech.principles.map((principle,itemIndex)=>`<div><b>0${itemIndex+1}</b><span>${principle}</span></div>`).join('')}</div>`;
  if(techTab==='limitation')html=`<div class="limitation"><span>工程边界 / ENGINEERING GAP</span><h3>为什么现实还不是电影效果？</h3><p>${tech.limitation}</p></div>`;
  if(id!==activeTech)return;
  $('#techContent').innerHTML=html;$('#techStep').textContent=`0${index+1} / ${TAB_NAMES[techTab]}`;$('#techNext').style.display=index===3?'none':'inline-block';$('#techDeploy').textContent=TECH_ACTIONS[id];
  $$('[data-video-preview]').forEach(node=>node.onclick=()=>openVideoPreview(node.dataset.videoPreview));
}
function openTech(id){
  if(!id)return;activeTech=id;techTab='fiction';const tech=BLACKOUT_DATA.techs[id];$('#techTitle').textContent=TECH_LABELS[id]||tech.name;
  $$('#techTabs button').forEach(button=>button.classList.toggle('active',button.dataset.tab==='fiction'));renderTech();modal('#techModal');beep(720,.08);
}
function deploy(){
  const scene=BLACKOUT_DATA.scenes[state.scene];if(!scene.tech)return;
  BlackoutSync.action('deploy',{tech:scene.tech});beep(880,.18);toast(`${TECH_LABELS[scene.tech]}已接入任务系统`);closeModals();
}
function openDecision(){const scene=BLACKOUT_DATA.scenes[state.scene];if(!scene.poll)return;renderPoll();modal('#pollModal');beep(330,.14,'square')}
async function renderMediaCenter(){
  $('#mediaSlotList').innerHTML=Object.keys(VIDEO_PATHS).map(id=>`<article class="media-slot" data-media="${id}"><div class="media-slot-icon">${BLACKOUT_DATA.techs[id].short}</div><div><h3>${TECH_LABELS[id]}</h3><p>${VIDEO_PATHS[id]}</p></div><div class="media-slot-actions"><button class="media-preview-btn" data-preview="${id}">预览窗口</button><em>检查中</em></div></article>`).join('');
  await Promise.all(Object.keys(VIDEO_PATHS).map(async id=>{const ready=await probeVideo(id);const card=$(`[data-media="${id}"]`);if(!card)return;card.classList.toggle('ready',ready);card.querySelector('em').textContent=ready?'素材已接入':'等待素材'}));
  $$('[data-preview]').forEach(button=>button.onclick=()=>openVideoPreview(button.dataset.preview));
}
function openMedia(){renderMediaCenter();modal('#mediaModal')}
async function openVideoPreview(id,options={}){
  const ready=await probeVideo(id);const filename=VIDEO_PATHS[id].split('/').pop();const currentScene=options.scene||BLACKOUT_DATA.scenes[state.scene];closeModals();
  $('#videoPreviewTitle').textContent=VIDEO_DESCRIPTIONS[id];$('#videoSceneContext').textContent=`场景 ${currentScene.number} · ${currentScene.title}｜${currentScene.objective}`;$('#videoPreviewFile').textContent=`素材位置：D:\\战域·2035\\assets\\videos\\${filename}`;
  $('#videoPreviewStage').innerHTML=ready?`<video src="${VIDEO_PATHS[id]}" autoplay muted loop playsinline controls></video>`:`<div class="cinema-placeholder"><div class="cinema-play"></div><div class="cinema-meta"><div><span>${options.automatic?'情节已自动触发影片窗口':'影片预览窗口'}</span><b>${TECH_LABELS[id]}</b></div><small>${filename}<br>16:9 · 5–8秒</small></div></div>`;
  modal('#videoPreviewModal');beep(610,.08);
}
function renderUavConsole(){
  const airborne=state.uav?.mode==='airborne';const active=airborne?(state.uav?.active||24):0;const coverage=airborne?Math.max(88,BLACKOUT_DATA.scenes[state.scene].coverage):BLACKOUT_DATA.scenes[state.scene].coverage;
  $('#uavMode').textContent=airborne?'任务中 / AIRBORNE':'待命 / READY';$('#uavActive').textContent=`${active} / 24`;$('#uavCoverage').textContent=`${coverage}%`;$('#uavLink').textContent=airborne?'97%':'--';
  $('#launchUavBtn').disabled=airborne;$('#recallUavBtn').disabled=!airborne;
  $('#uavRoster').innerHTML=Array.from({length:24},(_,index)=>`<div class="uav-node ${airborne?'active':''}"><i></i><span><b>UAV-${String(index+1).padStart(2,'0')}</b><small>${airborne?['通信中继','区域扫描','目标搜索','热源侦测'][index%4]:'机库待命'}</small></span></div>`).join('');
}
function openUavConsole(){renderUavConsole();modal('#uavModal')}
function renderIntel(){
  const scene=BLACKOUT_DATA.scenes[state.scene];const cards=[['任务态势',scene.title,scene.objective,scene.progress],['传感器融合','多源数据已接入',`当前数据速率 ${scene.rate}，区域覆盖 ${scene.coverage}%。`,Math.min(100,scene.coverage)],['目标研判',scene.risk==='CRITICAL'?'存在高优先风险':'持续监测中',translateAlert(scene.alert),scene.risk==='CRITICAL'?86:58],['链路健康','联合网络稳定',`定位误差 ${scene.error}，观察员终端 ${state.connected||0} 个。`,state.demoMode?64:93]];
  $('#intelGrid').innerHTML=cards.map(([type,title,copy,value])=>`<article class="intel-card"><span>${type}</span><h3>${title}</h3><p>${copy}</p><div class="intel-meter"><i style="width:${value}%"></i></div></article>`).join('');
}
function openIntel(){renderIntel();modal('#intelModal')}
function setMapLayer(layer){mapLayer=layer;$$('[data-map-layer]').forEach(button=>button.classList.toggle('active',button.dataset.mapLayer===layer));renderMap(BLACKOUT_DATA.scenes[state.scene]);toast(`${{terrain:'地形影像',signal:'信号覆盖',thermal:'热成像',route:'路线规划'}[layer]}图层已启用`)}
function setMapZoom(next){mapZoom=Math.max(0,Math.min(2,next));renderMap(BLACKOUT_DATA.scenes[state.scene])}
function showEntity(id){const detail=ENTITY_DETAILS[id];if(!detail)return;const card=$('#entityCard');card.innerHTML=`<button aria-label="关闭">×</button><span>${detail[0]}</span><b>${detail[1]}</b><small>${detail[2]}</small>`;card.classList.remove('is-hidden');card.querySelector('button').onclick=()=>card.classList.add('is-hidden')}
async function toggleFullscreen(){try{if(!document.fullscreenElement)await document.documentElement.requestFullscreen();else await document.exitFullscreen()}catch(_error){toast('浏览器未允许全屏模式')}}

$$('[data-close]').forEach(button=>button.onclick=closeModals);
$('#enterBtn').onclick=enterOperation;$('#startMissionBtn').onclick=startMission;$('#briefingBtn').onclick=()=>modal('#briefingModal');$('#sceneNavBtn').onclick=()=>{renderSceneNavigation();modal('#sceneNavModal')};$('#uavConsoleBtn').onclick=openUavConsole;$('#intelBtn').onclick=openIntel;$('#mediaBtn').onclick=openMedia;$('#fullscreenBtn').onclick=toggleFullscreen;
$('#nextBtn').onclick=()=>BlackoutSync.action('next');$('#prevBtn').onclick=()=>BlackoutSync.action('prev');$('#alertBtn').onclick=()=>BlackoutSync.action('alert');$('#techBtn').onclick=()=>openTech(BLACKOUT_DATA.scenes[state.scene].tech);$('#deployBtn').onclick=deploy;$('#pollBtn').onclick=()=>state.poll?.open?BlackoutSync.action('closePoll'):openDecision();$('#helpBtn').onclick=()=>modal('#helpModal');
$('#openPollBtn').onclick=()=>{const pollId=BLACKOUT_DATA.scenes[state.scene].poll;if(pollId)BlackoutSync.action('openPoll',{pollId});renderPoll();toast('观察员终端投票已开启')};
$('#closePollBtn').onclick=()=>{BlackoutSync.action('closePoll');closeModals()};
$('#demoResultBtn').onclick=()=>{const pollId=BLACKOUT_DATA.scenes[state.scene].poll;BlackoutSync.action('demoResult',{pollId,votes:pollId==='ai'?{A:34,B:26}:{A:16,B:44}});renderPoll()};
$('#techDeploy').onclick=deploy;
$('#techNext').onclick=()=>{const tabs=['fiction','reality','principle','limitation'];techTab=tabs[Math.min(3,tabs.indexOf(techTab)+1)];$$('#techTabs button').forEach(button=>button.classList.toggle('active',button.dataset.tab===techTab));renderTech()};
$$('#techTabs button').forEach(button=>button.onclick=()=>{techTab=button.dataset.tab;$$('#techTabs button').forEach(item=>item.classList.toggle('active',item===button));renderTech()});
$('#copyObserver').onclick=async()=>{const info=await BlackoutSync.info();try{await navigator.clipboard.writeText(info.observerUrl);toast('观察员接入地址已复制')}catch(_error){toast(info.observerUrl)}};
$('#launchUavBtn').onclick=()=>{BlackoutSync.action('launchUav');toast('无人机群正在展开');beep(840,.2);setTimeout(closeModals,420)};
$('#recallUavBtn').onclick=()=>{BlackoutSync.action('recallUav');toast('无人机群已收到返航指令');beep(420,.16);renderUavConsole()};
$$('[data-map-layer]').forEach(button=>button.onclick=()=>setMapLayer(button.dataset.mapLayer));$('#mapZoomIn').onclick=()=>setMapZoom(mapZoom+1);$('#mapZoomOut').onclick=()=>setMapZoom(mapZoom-1);$('#mapZoomReset').onclick=()=>setMapZoom(0);
$$('.map-entity').forEach(entity=>{entity.addEventListener('click',()=>showEntity(entity.dataset.entity));entity.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' ')showEntity(entity.dataset.entity)})});

document.addEventListener('keydown',event=>{
  if(['INPUT','TEXTAREA'].includes(event.target.tagName))return;
  if(event.key==='Escape')return closeModals();if(modalOpen)return;
  if(event.key===' '){event.preventDefault();BlackoutSync.action('next')}
  const key=event.key.toLowerCase();if(key==='p')BlackoutSync.action('prev');if(key==='a')BlackoutSync.action('alert');if(key==='t')openTech(BLACKOUT_DATA.scenes[state.scene].tech);if(key==='v')state.poll?.open?BlackoutSync.action('closePoll'):openDecision();if(key==='d')deploy();if(key==='r'&&confirm('确定重置整场演示吗？'))BlackoutSync.action('reset',{scene:0});
});
window.addEventListener('hashchange',()=>{const match=location.hash.match(/^#tech-(.+)$/);if(match&&BLACKOUT_DATA.techs[match[1]])openTech(match[1])});
window.addEventListener('blackout-state',event=>render(event.detail));
setInterval(()=>$('#clock').textContent=new Date().toLocaleTimeString('zh-CN',{hour12:false}),1000);

BlackoutSync.info().then(info=>$('#observerUrl').textContent=info.observerUrl);
BlackoutSync.refresh().then(next=>{
  render(next);
  if(next.scene>0){missionEntered=true;$('#boot').classList.add('is-hidden');$('#dashboard').classList.remove('is-hidden')}
  const match=location.hash.match(/^#tech-(.+)$/);if(match&&BLACKOUT_DATA.techs[match[1]])openTech(match[1]);
});
