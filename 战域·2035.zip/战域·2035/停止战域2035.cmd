@echo off
chcp 65001 >nul
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":2035" ^| findstr "LISTENING"') do taskkill /PID %%a /F >nul 2>nul
echo 战域·2035 本地服务已停止。
timeout /t 2 >nul
