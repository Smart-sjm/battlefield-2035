const view=document.querySelector('#observerView');
const idLabel=document.querySelector('#observerId');
const signal=document.querySelector('#observerSignal');
let observerId=localStorage.getItem('blackout2035:observerId');
const voted=()=>JSON.parse(localStorage.getItem('blackout2035:voted')||'{}');
const makeId=()=>`OBSERVER-${String(Math.floor(1+Math.random()*999)).padStart(3,'0')}`;
function join(){observerId=observerId||makeId();localStorage.setItem('blackout2035:observerId',observerId);BlackoutSync.join(observerId).then(render)}
async function submit(pollId,option){const history=voted();if(history[pollId])return;history[pollId]=option;localStorage.setItem('blackout2035:voted',JSON.stringify(history));await BlackoutSync.vote(observerId,pollId,option);render()}
function render(){
  const state=BlackoutSync.state;const scene=BLACKOUT_DATA.scenes[state.scene]||BLACKOUT_DATA.scenes[0];idLabel.textContent=observerId||'UNREGISTERED';signal.className=BlackoutSync.remote?'online':'local';
  if(!observerId){view.innerHTML=`<div class="observer-hero"><span>请求接入 / ACCESS REQUEST</span><h1>接入联合任务网络</h1><p>加入后请保持页面开启。观察员终端只在关键节点接收投票指令，不会控制任务主线。</p><div class="access-code"><i></i><b>战域·2035 / 第七任务区</b></div><button class="primary-btn observer-main-btn" id="joinBtn">确认接入</button><small>无需注册，不收集姓名</small></div>`;document.querySelector('#joinBtn').onclick=join;return}
  if(scene.id==='complete'){view.innerHTML=`<div class="observer-state complete"><span>任务已完成 / SESSION COMPLETE</span><h1>任务结束</h1><div class="state-orb"><b>✓</b></div><p>2035年的系统，由今天已经开始发展的现实技术逐步组成。</p></div>`;return}
  const poll=state.poll?.id?BLACKOUT_DATA.polls[state.poll.id]:null;const history=voted();
  if(state.poll?.open&&poll){
    if(history[poll.id]){view.innerHTML=`<div class="observer-state submitted"><span>决策 ${poll.index} / DECISION</span><h1>指令已提交</h1><div class="state-orb"><b>✓</b></div><p>已选择 ${history[poll.id]}。等待指挥中心完成决策。</p><em>已提交 / 不可更改</em></div>`}
    else{view.innerHTML=`<div class="vote-terminal"><span>收到决策请求 / DECISION REQUEST</span><h1>${poll.title}</h1><p>${poll.question}</p><div class="vote-options">${poll.options.map(o=>`<button data-option="${o.id}"><b>${o.id}</b><span>${o.label}</span><i>选择</i></button>`).join('')}</div><small>每个观察员只能提交一次</small></div>`;document.querySelectorAll('[data-option]').forEach(b=>b.onclick=()=>submit(poll.id,b.dataset.option))}
    return
  }
  view.innerHTML=`<div class="observer-state standby"><span>系统已连接 / SYSTEM CONNECTED</span><h1>${scene.title}</h1><div class="state-orb"><b>${scene.number}</b></div><h2>${scene.code}</h2><p>${scene.objective}</p><em><i></i> 等待下一条指挥请求</em></div>`;
}
window.addEventListener('blackout-state',render);BlackoutSync.refresh().then(render);
