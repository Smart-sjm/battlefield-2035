import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';

const root=path.dirname(fileURLToPath(import.meta.url));
const port=Number(process.env.PORT||2035);
const scenes=11;
const joined=new Set();
const state={scene:0,connected:18,demoMode:false,alertPulse:0,deployed:{},uav:{mode:'ready',active:0,sorties:0},poll:{id:null,open:false,votes:{A:0,B:0},voters:{}},updatedAt:Date.now()};
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.json':'application/json; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.mp4':'video/mp4','.mp3':'audio/mpeg'};
const json=(res,code,data)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Access-Control-Allow-Origin':'*'});res.end(JSON.stringify(data))};
const body=req=>new Promise((resolve,reject)=>{let data='';req.on('data',c=>{data+=c;if(data.length>1e6)reject(new Error('large'))});req.on('end',()=>{try{resolve(data?JSON.parse(data):{})}catch(e){reject(e)}})});
const touch=()=>{state.updatedAt=Date.now();return state};
function lanIp(){for(const entries of Object.values(os.networkInterfaces()))for(const n of entries||[])if(n.family==='IPv4'&&!n.internal)return n.address;return'127.0.0.1'}
async function route(req,res){
  const url=new URL(req.url,'http://localhost');
  if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type'});return res.end()}
  if(url.pathname==='/api/state')return json(res,200,state);
  if(url.pathname==='/api/info')return json(res,200,{observerUrl:`http://${lanIp()}:${port}/observer.html`,controlUrl:`http://${lanIp()}:${port}/control.html`,remote:true});
  if(url.pathname==='/api/media')return json(res,200,Object.fromEntries(['ar','nav','exo','uav','ai','dew'].map(id=>[id,fs.existsSync(path.join(root,'assets','videos',`${id}-fiction.mp4`))])));
  if(url.pathname==='/api/join'&&req.method==='POST'){const b=await body(req);if(b.observerId&&!joined.has(b.observerId)){joined.add(b.observerId);state.connected=Math.max(18,joined.size+18)}return json(res,200,touch())}
  if(url.pathname==='/api/vote'&&req.method==='POST'){const b=await body(req);if(state.poll.open&&state.poll.id===b.pollId&&['A','B'].includes(b.option)&&!state.poll.voters[b.observerId]){state.poll.voters[b.observerId]=b.option;state.poll.votes[b.option]=(state.poll.votes[b.option]||0)+1}return json(res,200,touch())}
  if(url.pathname==='/api/action'&&req.method==='POST'){
    const b=await body(req);if(b.type==='setScene')state.scene=Math.max(0,Math.min(scenes-1,Number(b.scene)));if(b.type==='next')state.scene=Math.min(scenes-1,state.scene+1);if(b.type==='prev')state.scene=Math.max(0,state.scene-1);if(b.type==='toggleDemo')state.demoMode=!state.demoMode;if(b.type==='alert')state.alertPulse++;if(b.type==='deploy')state.deployed[b.tech]=true;if(b.type==='launchUav')state.uav={mode:'airborne',active:24,sorties:(state.uav?.sorties||0)+1};if(b.type==='recallUav')state.uav={...(state.uav||{}),mode:'ready',active:0};if(b.type==='openPoll')state.poll={id:b.pollId,open:true,votes:{A:0,B:0},voters:{}};if(b.type==='closePoll')state.poll.open=false;if(b.type==='demoResult')state.poll={id:b.pollId||state.poll.id,open:false,votes:b.votes||{A:18,B:42},voters:{}};if(b.type==='reset'){joined.clear();Object.assign(state,{scene:Number(b.scene||0),connected:18,demoMode:false,alertPulse:0,deployed:{},uav:{mode:'ready',active:0,sorties:0},poll:{id:null,open:false,votes:{A:0,B:0},voters:{}}})}return json(res,200,touch())
  }
  let file=url.pathname==='/'?'index.html':decodeURIComponent(url.pathname.slice(1));file=path.normalize(file);const full=path.resolve(root,file);if(!full.startsWith(root)||!fs.existsSync(full)||fs.statSync(full).isDirectory())return json(res,404,{error:'not found'});res.writeHead(200,{'Content-Type':types[path.extname(full).toLowerCase()]||'application/octet-stream','Cache-Control':'no-cache'});fs.createReadStream(full).pipe(res);
}
const server=http.createServer((req,res)=>route(req,res).catch(e=>json(res,500,{error:e.message})));
server.listen(port,'0.0.0.0',()=>{console.log('\n战域·2035 已启动');console.log(`大屏：http://127.0.0.1:${port}`);console.log(`手机：http://${lanIp()}:${port}/observer.html`);console.log(`主控：http://127.0.0.1:${port}/control.html\n`)});
