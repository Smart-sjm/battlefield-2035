@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "NODE_EXE=node"
where node >nul 2>nul
if errorlevel 1 set "NODE_EXE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
if not exist "%NODE_EXE%" (
  echo 未找到 Node.js。请先在 Codex 中启动本项目，或安装 Node.js。
  pause
  exit /b 1
)
start "战域2035服务" /min "%NODE_EXE%" "%~dp0server.mjs"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:2035/"
exit /b 0
